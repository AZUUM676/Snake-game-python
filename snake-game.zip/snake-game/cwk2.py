import pygame  #import pygame to support play the game
import random  # to allow randomization of objects 

# Initialize pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600  # Screen dimensions
BLOCK_SIZE = 20  # Size of each block in the grid
WHITE = (255, 255, 255) 
RED = (255, 0, 0) 
DARK_GREEN = (0,100,0)  
GOLD = (255, 215, 0)  
BLUE = (0, 0, 255)  
ORANGE = (255, 165, 0)   
PURPLE = (128, 0, 128) 
NAVY = (0, 0, 128)  
FPS = 7  # Initial game speed (frames per second)

# Initialize pygame window
win = pygame.display.set_mode((WIDTH, HEIGHT))  #  specify the dimensions of the window
pygame.display.set_caption("SNAKE GAME")  # name the window title

# Load assets
background_img = pygame.image.load("back.jpg")  # Load and scale background image to the window
background_img = pygame.transform.scale(background_img, (WIDTH, HEIGHT)) 
icon_img = pygame.image.load("ba.png")  # logo menu image
icon_img = pygame.transform.scale(icon_img, (200, 100))  
obstacle_img = pygame.image.load("sto.png") # obstacle image(tree)
obstacle_img = pygame.transform.scale(obstacle_img, (BLOCK_SIZE, BLOCK_SIZE))
menu_img = pygame.image.load("bac.jpeg")  # image of menu background
menu_img = pygame.transform.scale(menu_img, (WIDTH, HEIGHT))  
game_over_img = pygame.image.load("gm.png")  #image on gameover
game_over_img = pygame.transform.scale(game_over_img, (600,200 )) 


# Sound effects
eat_sound = pygame.mixer.Sound("food.mp3")  # Load sound for eating food
game_over_sound = pygame.mixer.Sound("game-over.mp3")  # Load sound for game over


# Classes

class Snake:
    #Initialize the snake with a body, direction, and images for both head and body.
    def __init__(self):
        self.body = [[WIDTH // 2, HEIGHT // 2]]  # Snake starts at the center of the screen
        self.direction = [BLOCK_SIZE, 0,]  # Initial direction in this case the right
        self.growing = False  # Indicates whether there is growth of snake
        self.head_img = pygame.image.load("head.png")  # Load snake head image
        self.head_img = pygame.transform.scale(self.head_img, (BLOCK_SIZE, BLOCK_SIZE)) 
        self.body_img = pygame.image.load("body.png")  # Load snake body image
        self.body_img = pygame.transform.scale(self.body_img, (BLOCK_SIZE, BLOCK_SIZE)) 

#Update the snake's position based on its direction
    def move(self):
        head = [self.body[0][0] + self.direction[0], self.body[0][1] + self.direction[1]]  # Calculate new head position
        if not self.growing:
            self.body.pop()  # Remove the last segment if not growing
        else:
            self.growing = False  # Reset growing status after adding one segment
        self.body.insert(0, head)  # Add new head

#set the growth flag to grow the snake.
    def grow(self):
        self.growing = True

#Checking for collisions with itself, boundaries or obstacles.
    def check_collision(self, obstacles):
        head = self.body[0]  # snake's head position
        # collision with itself
        if head in self.body[1:]:
            return True
        # collision with screen boundaries
        if head[0] < 0 or head[0] >= WIDTH or head[1] < 0 or head[1] >= HEIGHT:
            return True
        # collision with obstacles
        if head in obstacles:
            return True
        return False

#Draw the snake on the screen    
    def draw(self):
         for index, segment in enumerate(self.body):
            if index == 0:
                win.blit(self.head_img, (segment[0], segment[1]))  # Draw head
            else:
                win.blit(self.body_img, (segment[0], segment[1]))  # Draw body

#Initialize the food 
class Food:
    def __init__(self,obstacles):
        self.obstacles = obstacles
        self.position = self.spawn()  # Spawn food at a random position
        self.food_img = pygame.image.load("apple.png")  # Load food image
        self.food_img = pygame.transform.scale(self.food_img, (BLOCK_SIZE, BLOCK_SIZE)) 

#Generate a random position for the food.
    def spawn(self):
        while True:
            x = random.randint(0, (WIDTH - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            y = random.randint(0, (HEIGHT - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            if [x,y] not in self.obstacles:
                return [x, y]
 
#Draw the food on the screen.
    def draw(self):
        win.blit(self.food_img, (self.position[0], self.position[1]))

#Initialize obstacles
class Obstacle:
    def __init__(self, num_obstacles = 8):
        self.num_obstacles = num_obstacles  # Number of obstacles to create
        self.positions = self.spawn_obstacles()  # create obstacle positions

#Generate random positions for obstacles.
    def spawn_obstacles(self):
        obstacles = []
        while len(obstacles) < self.num_obstacles:
            x = random.randint(0, (WIDTH - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            y = random.randint(0, (HEIGHT - BLOCK_SIZE) // BLOCK_SIZE) * BLOCK_SIZE
            new_obstacle = [x, y]
            if new_obstacle not in obstacles:  # Avoid duplicate obstacles
                obstacles.append(new_obstacle)
        return obstacles

#Draw obstacles on the screen."""
    def draw(self):
       for pos in self.positions:
            win.blit(obstacle_img, (pos[0], pos[1]))

#Initialize the game with a snake, food, obstacles and initial settings.
class Game:
    def __init__(self):
        self.snake = Snake() 
        self.obstacle = Obstacle()
        self.food = Food(self.obstacle.positions)
       
        self.score = 0  # Player's score
        self.level = 1  # Current level
        self.running = True  # Game running status

#start menu screen display.
    def start_menu(self):
        win.fill(WHITE)
        win.blit(menu_img, (0,0)) 
        title_font = pygame.font.SysFont("Lucida handwriting", 60)  # Title font
        menu_font = pygame.font.SysFont("Kristen ITC", 30)  # Menu font
        title_text = title_font.render("Snake Game", True, DARK_GREEN)
        play_text = menu_font.render("Press P to Play", True, BLUE)
        instructions_text = menu_font.render("Press I for Instructions", True, GOLD)
        quit_text = menu_font.render("Press Q to Quit", True, WHITE)
        win.blit(icon_img, (WIDTH // 2 - icon_img.get_width() // 2, HEIGHT // 4 - 60))  # Display logo
        win.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 3))
        win.blit(play_text, (WIDTH // 2 - play_text.get_width() // 2, HEIGHT // 2))
        win.blit(instructions_text, (WIDTH // 2 - instructions_text.get_width() // 2, HEIGHT // 2 + 40))
        win.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 80))
        pygame.display.update()


                # Wait for user input in the start menu
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False  # Exit game if the window is closed
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        return  # Start the game if P is pressed
                    elif event.key == pygame.K_i:
                        self.instructions_menu()  # Show instructions if I is pressed
                    elif event.key == pygame.K_q:
                        self.running = False  # Quit the game if Q is pressed
                        return
#instructions screen.
    def instructions_menu(self):
        win.fill(NAVY) 
        instructions_font = pygame.font.SysFont("Segoe Print", 30)  # Font for instructions
        instructions = [
                  " ** HELP MENU **",
            "1. Use Arrow Keys to move the snake.",
            "2. Eat the red apples to grow.",
            "3. Avoid colliding with", "*  Boarder Walls", "* Yourself", "* Tree trunks.",
            "Press:-", "P to Play or Q to Quit.",
        ]
        y_offset = HEIGHT // 6  # vertical offset for the text respect with the height
# Displaying the instructions one by one in line
        for line in instructions:
            text = instructions_font.render(line, True, ORANGE)
            win.blit(text, (WIDTH // 2 - text.get_width() // 2, y_offset))
            y_offset += 50  # Move text down
        pygame.display.update()

        # Wait for user input in the instructions menu
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False  # Exit game if the window is closed
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        return  # Start the game if P is pressed
                    elif event.key == pygame.K_q:
                        self.running = False  # Quit the game if Q is pressed
                        return

#Drawing the score and level HUD on the screen."""
    def draw_hud(self):
        score_font = pygame.font.SysFont("Maiandra GD", 30)  # Font for score and level
        score_text = score_font.render(f"SCORE: {self.score}", True,WHITE)  # Render score text
        level_text = score_font.render(f"LEVEL: {self.level}", True, WHITE)  # Render level text
        win.blit(score_text, (5, 5))  # Draw score on top-left corner
        win.blit(level_text, (5, 40))  # Draw level on top-left corner below the score level

#game-over screen display.
    def game_over_screen(self):
        win.fill(PURPLE)  # Set background to purple
        menu_font = pygame.font.SysFont("Segoe Print", 30)  # menu font
        score_text = menu_font.render(f"Final Score: -- {self.score} --", True, RED)  # Render final score text
        restart_text = menu_font.render("Press R to Restart Game or Q to Quit", True, ORANGE)  # Render restart/quit text
        win.blit(game_over_img, (WIDTH // 2 - game_over_img.get_width() // 2, HEIGHT // 4 - 60))  # Display logo
        win.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))  # Draw final score
        win.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 40))  # Draw restart/quit option
        pygame.display.update()

        # Play game-over sound
        game_over_sound.play()

        # Wait for user input on game over screen
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False  # Exit the game if the window is closed
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.__init__()  # Reset the game by reinitializing the class by preesing r
                        return
                    elif event.key == pygame.K_q:
                        self.running = False  # Quit the game if Q is pressed
                        return

#Increase game difficulty as score increases.
    def increase_difficulty(self):
       if self.score > 0 and self.score % 5 == 0:  # Increase level every 5 points
            self.level += 1  # Increase the level
            global FPS
            FPS += 3 # Increase the game's speed by increasing FPS

#Run the game loop.
    def run(self):
        self.start_menu()  # Display the start menu first
        clock = pygame.time.Clock()  # Create a clock to control frame rate
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False  # Exit the game if the window is closed
                keys = pygame.key.get_pressed()  # Get pressed keys
                if keys[pygame.K_UP] and self.snake.direction[1] == 0:  # Check if UP key is pressed and snake is not moving vertically
                    self.snake.direction = [0, -BLOCK_SIZE]  # Move up
                elif keys[pygame.K_DOWN] and self.snake.direction[1] == 0:  # Check if DOWN key is pressed and snake is not moving vertically
                    self.snake.direction = [0, BLOCK_SIZE]  # Move down
                elif keys[pygame.K_LEFT] and self.snake.direction[0] == 0:  # Check if LEFT key is pressed and snake is not moving horizontally
                    self.snake.direction = [-BLOCK_SIZE, 0]  # Move left
                elif keys[pygame.K_RIGHT] and self.snake.direction[0] == 0:  # Check if RIGHT key is pressed and snake is not moving horizontally
                    self.snake.direction = [BLOCK_SIZE, 0]  # Move right

            self.snake.move()  # Move the snake

            # Check if snake eats food
            if self.snake.body[0] == self.food.position:
                self.snake.grow()  # Grow the snake
                self.food.position = self.food.spawn()  # spawn new food 
                self.score += 1  # Increase the score
                eat_sound.play()  # Play eat sound
                self.increase_difficulty()  # Increase the difficulty based on score

            # Check if snake collides with obstacles
            if self.snake.check_collision(self.obstacle.positions):
                self.game_over_screen()  # Show the game over screen if collision happens

            # Draw everything
            win.fill(WHITE)  # Fill the screen with white background
            win.blit(background_img, (0, 0))  # Draw the background image
            self.snake.draw()  # Draw the snake
            self.food.draw()  # Draw the food
            self.obstacle.draw()  # Draw obstacles (trees)
            self.draw_hud()  # Draw the HUD (score and level)
            pygame.display.update()  # Update the display

            pygame.time.Clock().tick(FPS)  # Control the game speed based on FPS

       
        pygame.quit()  # Close pygame

# Start the game
game = Game()  # Create a game instance
game.run()  # Run the game

